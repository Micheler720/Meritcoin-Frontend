import styled from 'styled-components';

export const Content = styled.div`
  padding: 1rem;
  position: relative;
  margin-top: 2rem;
`;
