import styled from 'styled-components';

export const Container = styled.div`
  top: 0.5rem;
  right: 0.5rem;
  position: absolute;
`;
